﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPGroupAssign
{
    internal class Booking
    {
        public string BookingDate { get; }
        public int BookingNumber { get; }
        public Flight Flight { get; }
        public Customer Customer { get; }

        private static int nextBookingNumber = 1;

        
        public Booking(Flight flight, Customer customer, bool performActions = true)
        {
            BookingDate = DateTime.Now.ToString(@"MM\/dd\/yyyy h\:mm tt");
            BookingNumber = nextBookingNumber++;
            Flight = flight;
            Customer = customer;

            if (performActions)
            {
                // Increment the booking count for the associated customer and book a passenger on the flight.
                Customer.IncrementBookingCount();
                Flight.BookPassenger();
            }
        }

    }

}
