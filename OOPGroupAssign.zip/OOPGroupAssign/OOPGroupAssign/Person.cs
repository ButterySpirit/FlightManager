﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPGroupAssign
{
    internal class Person
    {
        private string fname;
        private string lname;
        
        public Person(string fname,string lname) {
            this.fname = fname;   
            this.lname = lname; 
            
        }

        public string FirstName { get { return fname; } }
        public string LastName { get { return lname; } }

    }
}
