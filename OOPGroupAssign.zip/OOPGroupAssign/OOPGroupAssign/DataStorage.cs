﻿using System;
using System.IO;
using System.Linq;

namespace OOPGroupAssign
{
    internal class DataStorage
    {
        private string dataFolderPath;

        public DataStorage()
        {
            // Construct the path to the data folder using a relative path
            string appDirectory = AppDomain.CurrentDomain.BaseDirectory;
            dataFolderPath = Path.Combine(appDirectory, "data");

            // Ensure that the data folder exists
            Directory.CreateDirectory(dataFolderPath);
        }

        public string[] ReadDataFromFile(string fileName)
        {
            string filePath = Path.Combine(dataFolderPath, fileName);
            try
            {
                return File.ReadAllLines(filePath);
            }
            catch (Exception e)
            {
                Console.WriteLine($"Error reading data from file {fileName}: {e.Message}");
                return new string[0];
            }
        }

        public void WriteDataToFile(string fileName, string[] data)
        {
            string filePath = Path.Combine(dataFolderPath, fileName);
            try
            {
                File.WriteAllLines(filePath, data);
            }
            catch (Exception e)
            {
                Console.WriteLine($"Error writing data to file {fileName}: {e.Message}");
            }
        }

        public string[] ReadCustomers()
        {
            return ReadDataFromFile("Customers.txt");
        }

        public void WriteCustomers(string[] data)
        {
            WriteDataToFile("Customers.txt", data);
        }

        public string[] ReadFlights()
        {
            return ReadDataFromFile("Flights.txt");
        }

        public void WriteFlights(string[] data)
        {
            WriteDataToFile("Flights.txt", data);
        }

        public string[] ReadBookings()
        {
            return ReadDataFromFile("Bookings.txt");
        }

        public void WriteBookings(string[] data)
        {
            WriteDataToFile("Bookings.txt", data);
        }

        public string[] SplitData(string input, char delimiter = '|')
        {
            return input.Split(delimiter);
        }

        public string CombineData(string[] values, char delimiter = '|')
        {
            return string.Join(delimiter.ToString(), values);
        }
    }
}
