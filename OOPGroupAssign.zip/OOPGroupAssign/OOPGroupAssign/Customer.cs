﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPGroupAssign
{
    internal class Customer : Person
    {
        public int CustomerID { get; }
        public string Phone { get; }
        public int BookingCount { get; private set; }

        public static int nextCustomerID = 1;

        public Customer(string firstName, string lastName, string phone)
            : base(firstName, lastName)
        {
            CustomerID = nextCustomerID++;
            Phone = phone;
            BookingCount = 0;
        }

        public void IncrementBookingCount()
        {
            BookingCount++;
        }
    }
}


