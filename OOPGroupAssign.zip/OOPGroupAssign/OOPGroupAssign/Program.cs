﻿using System;

namespace OOPGroupAssign
{
    class Program
    {
        static void Main(string[] args)
        {
            AirlineCoordinator airlineCoordinator = new AirlineCoordinator(maxFlights: 100, maxCustomers: 100, maxBookings: 500);

            while (true)
            {
                Console.WriteLine("Main Menu:");
                Console.WriteLine("1. Customers");
                Console.WriteLine("2. Flights");
                Console.WriteLine("3. Bookings");
                Console.WriteLine("4. Exit");
                Console.Write("Enter your choice: ");

                if (int.TryParse(Console.ReadLine(), out int choice))
                {
                    switch (choice)
                    {
                        case 1:
                            HandleCustomersSubMenu(airlineCoordinator);
                            Console.Clear();
                            break;

                        case 2:
                            HandleFlightsSubMenu(airlineCoordinator);
                            Console.Clear();
                            break;

                        case 3:
                            HandleBookingsSubMenu(airlineCoordinator);
                            Console.Clear();
                            break;

                        case 4:
                            // Exit
                            return;

                        default:
                            Console.WriteLine("Invalid choice. Please try again.");
                            Console.Clear();
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("Invalid input. Please enter a valid choice.");
                }
            }
        }

        static void HandleCustomersSubMenu(AirlineCoordinator airlineCoordinator)
        {
            while (true)
            {
                Console.WriteLine("\nCustomers Menu:");
                Console.WriteLine("1. Add Customer");
                Console.WriteLine("2. View Customers");
                Console.WriteLine("3. Delete Customer");
                Console.WriteLine("4. Back to Main Menu");
                Console.Write("Enter your choice: ");

                if (int.TryParse(Console.ReadLine(), out int customerChoice))
                {
                    switch (customerChoice)
                    {
                        case 1:
                            // Add Customer
                            string firstName, lastName, phone;
                            do
                            {
                                Console.Write("Enter first name: ");
                                firstName = Console.ReadLine();
                            } while (string.IsNullOrWhiteSpace(firstName));

                            do
                            {
                                Console.Write("Enter last name: ");
                                lastName = Console.ReadLine();
                            } while (string.IsNullOrWhiteSpace(lastName));

                            do
                            {
                                Console.Write("Enter phone number: ");
                                phone = Console.ReadLine();
                            } while (string.IsNullOrWhiteSpace(phone));

                            airlineCoordinator.AddCustomer(firstName, lastName, phone);
                            break;

                        case 2:
                            // View Customers
                            airlineCoordinator.ViewCustomers();
                            break;

                        case 3:
                            // Delete Customer
                            Console.Write("Enter Customer ID to delete: ");
                            if (int.TryParse(Console.ReadLine(), out int customerIDToDelete))
                            {
                                airlineCoordinator.DeleteCustomer(customerIDToDelete);
                            }
                            else
                            {
                                Console.WriteLine("Invalid input. Please enter a valid Customer ID.");
                            }
                            break;

                        case 4:
                            return; // Exit the submenu and return to the main menu

                        default:
                            Console.WriteLine("Invalid choice. Please try again.");
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("Invalid input. Please enter a valid choice.");
                }
            }
        }

        static void HandleFlightsSubMenu(AirlineCoordinator airlineCoordinator)
        {
            while (true)
            {
                Console.WriteLine("\nFlights Menu:");
                Console.WriteLine("1. Add Flight");
                Console.WriteLine("2. View Flights");
                Console.WriteLine("3. View a Particular Flight");
                Console.WriteLine("4. Delete Flight");
                Console.WriteLine("5. Back to Main Menu");
                Console.Write("Enter your choice: ");

                if (int.TryParse(Console.ReadLine(), out int flightChoice))
                {
                    switch (flightChoice)
                    {
                        case 1:
                            // Add Flight
                            int flightNumber, maxSeats;
                            string origin, destination;

                            do
                            {
                                Console.Write("Enter flight number: ");
                            } while (!int.TryParse(Console.ReadLine(), out flightNumber) || flightNumber <= 0);

                            do
                            {
                                Console.Write("Enter origin: ");
                                origin = Console.ReadLine();
                            } while (string.IsNullOrWhiteSpace(origin));

                            do
                            {
                                Console.Write("Enter destination: ");
                                destination = Console.ReadLine();
                            } while (string.IsNullOrWhiteSpace(destination));

                            do
                            {
                                Console.Write("Enter maximum seats: ");
                            } while (!int.TryParse(Console.ReadLine(), out maxSeats) || maxSeats <= 0);

                            airlineCoordinator.AddFlight(flightNumber, origin, destination, maxSeats);
                            break;

                        case 2:
                            // View Flights
                            airlineCoordinator.ViewFlights();
                            break;

                        case 3:
                            // View a Particular Flight
                            Console.Write("Enter flight number: ");
                            if (int.TryParse(Console.ReadLine(), out int flightNumberToView))
                            {
                                Flight flight = airlineCoordinator.FindFlightByNumber(flightNumberToView);

                                if (flight != null)
                                {
                                    // Find and display the booked customers for this flight
                                    var flightBookings = airlineCoordinator.FindBookingsForFlight(flight.FlightNumber);
                                    if (flightBookings.Length > 0)
                                    {
                                        Console.WriteLine("Booked Customers:");
                                        foreach (var booking in flightBookings)
                                        {
                                            Console.WriteLine($"  - Customer ID: {booking.CustomerID}, Name: {booking.FirstName} {booking.LastName}");
                                        }
                                    }
                                    else
                                    {
                                        Console.WriteLine("No customers booked on this flight.");
                                    }
                                }
                                else
                                {
                                    Console.WriteLine("Flight not found.");
                                }
                            }
                            else
                            {
                                Console.WriteLine("Invalid input. Please enter a valid flight number.");
                            }
                            break;

                        case 4:
                            // Delete Flight
                            Console.Write("Enter flight number to delete: ");
                            if (int.TryParse(Console.ReadLine(), out int flightNumberToDelete))
                            {
                                airlineCoordinator.DeleteFlight(flightNumberToDelete);
                            }
                            else
                            {
                                Console.WriteLine("Invalid input. Please enter a valid flight number.");
                            }
                            break;

                        case 5:
                            return; // Exit the submenu and return to the main menu

                        default:
                            Console.WriteLine("Invalid choice. Please try again.");
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("Invalid input. Please enter a valid choice.");
                }
            }
        }

        static void HandleBookingsSubMenu(AirlineCoordinator airlineCoordinator)
        {
            while (true)
            {
                Console.WriteLine("\nBookings Menu:");
                Console.WriteLine("1. Make Booking");
                Console.WriteLine("2. View Bookings");
                Console.WriteLine("3. Back to Main Menu");
                Console.Write("Enter your choice: ");

                if (int.TryParse(Console.ReadLine(), out int bookingChoice))
                {
                    switch (bookingChoice)
                    {
                        case 1:
                            // Make Booking
                            Console.WriteLine("List of Customers:");
                            airlineCoordinator.ViewCustomers();
                            Console.Write("Enter Customer ID: ");
                            if (int.TryParse(Console.ReadLine(), out int customerID))
                            {
                                Console.WriteLine("\nList of Flights:");
                                airlineCoordinator.ViewFlights();
                                Console.Write("Enter Flight Number: ");
                                if (int.TryParse(Console.ReadLine(), out int flightNumber))
                                {
                                    bool bookingSuccess = airlineCoordinator.MakeBooking(flightNumber, customerID);
                                    if (bookingSuccess)
                                    {
                                        Console.WriteLine("Booking successful!");
                                    }
                                    else
                                    {
                                        Console.WriteLine("Booking failed. Please check flight availability and customer details.");
                                    }
                                }
                                else
                                {
                                    Console.WriteLine("Invalid input. Please enter a valid Flight Number.");
                                }
                            }
                            else
                            {
                                Console.WriteLine("Invalid input. Please enter a valid Customer ID.");
                            }
                            break;

                        case 2:
                            // View Bookings
                            airlineCoordinator.ViewBookings();
                            break;

                        case 3:
                            return; // Exit the submenu and return to the main menu

                        default:
                            Console.WriteLine("Invalid choice. Please try again.");
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("Invalid input. Please enter a valid choice.");
                }
            }
        }
    }
}
