﻿using System;

namespace OOPGroupAssign
{
    internal class AirlineCoordinator
    {
        private Flight[] flights;
        private Customer[] customers;
        private Booking[] bookings;
        private DataStorage dataStorage;

        public AirlineCoordinator(int maxFlights, int maxCustomers, int maxBookings)
        {
            flights = new Flight[maxFlights];
            customers = new Customer[maxCustomers];
            bookings = new Booking[maxBookings];
            dataStorage = new DataStorage();

            // Load data from files during initialization
            LoadCustomersFromDataStorage();
            LoadFlightsFromDataStorage();
            LoadBookingsFromDataStorage();
        }

        // Flight operations
        public bool AddFlight(int flightNumber, string origin, string destination, int maxSeats)
        {
            if (FindFlightByNumbers(flightNumber) == null)
            {
                for (int i = 0; i < flights.Length; i++)
                {
                    if (flights[i] == null)
                    {
                        flights[i] = new Flight(flightNumber, origin, destination, maxSeats);
                        UpdateFlightsInDataStorage(); // Update the Flights.txt file
                        return true;
                    }
                }
            }
            else
            {
                Console.WriteLine("Flight with the same number already exists.");
            }
            return false;
        }

        public Flight FindFlightByNumber(int flightNumber)
        {
            Flight flight = null;
            foreach (var f in flights)
            {
                if (f != null && f.FlightNumber == flightNumber)
                {
                    flight = f;
                    break;
                }
            }

            if (flight != null)
            {
                Console.WriteLine($"Flight Number: {flight.FlightNumber}, Origin: {flight.Origin}, Destination: {flight.Destination}, Max Seats: {flight.MaxSeats}, Passengers Booked: {flight.CurrentPassengerCount}");
            }
            return flight;
        }

        public Flight FindFlightByNumbers(int flightNumber)
        {
            Flight flight = null;
            foreach (var f in flights)
            {
                if (f != null && f.FlightNumber == flightNumber)
                {
                    flight = f;
                    break;
                }
            }
            return flight;
        }

        public void ViewFlights()
        {
            foreach (var flight in flights)
            {
                if (flight != null)
                {
                    Console.WriteLine($"Flight Number: {flight.FlightNumber}, Origin: {flight.Origin}, Destination: {flight.Destination}, Max Seats: {flight.MaxSeats}, Passengers Booked: {flight.CurrentPassengerCount}");
                }
            }
        }

        public bool DeleteFlight(int flightNumber)
        {
            Flight flightToDelete = FindFlightByNumbers(flightNumber);

            if (flightToDelete != null)
            {
                if (!CheckIfFlightHasCustomers(flightToDelete))
                {
                    for (int i = 0; i < flights.Length; i++)
                    {
                        if (flights[i] == flightToDelete)
                        {
                            flights[i] = null; // Delete the flight by setting the array entry to null
                            UpdateFlightsInDataStorage(); // Update the Flights.txt file
                            return true;
                        }
                    }
                }
                else
                {
                    Console.WriteLine("Cannot delete this flight. Customers are booked on this flight.");
                }
            }
            else
            {
                Console.WriteLine("Flight not found.");
            }

            return false;
        }

        // Customer operations
        public bool AddCustomer(string firstName, string lastName, string phone)
        {
            if (FindCustomerByDetails(firstName, lastName, phone) == null)
            {
                for (int i = 0; i < customers.Length; i++)
                {
                    if (customers[i] == null)
                    {
                        customers[i] = new Customer(firstName, lastName, phone);
                        UpdateCustomersInDataStorage(); // Update the Customers.txt file
                        return true;
                    }
                }
            }
            else
            {
                Console.WriteLine("Customer with the same details already exists.");
            }
            return false;
        }

        public Customer FindCustomerByDetails(string firstName, string lastName, string phone)
        {
            Customer customer = null;
            foreach (var c in customers)
            {
                if (c != null && c.FirstName == firstName && c.LastName == lastName && c.Phone == phone)
                {
                    customer = c;
                    break;
                }
            }
            return customer;
        }

        public void ViewCustomers()
        {
            foreach (var customer in customers)
            {
                if (customer != null)
                {
                    Console.WriteLine($"Customer ID: {customer.CustomerID}, Name: {customer.FirstName} {customer.LastName}, Phone: {customer.Phone}");
                }
            }
        }

        public (int CustomerID, string FirstName, string LastName)[] FindBookingsForFlight(int flightNumber)
        {
            (int CustomerID, string FirstName, string LastName)[] flightBookings = new (int, string, string)[bookings.Length];
            int count = 0;

            foreach (var booking in bookings)
            {
                if (booking != null && booking.Flight.FlightNumber == flightNumber)
                {
                    flightBookings[count] = (booking.Customer.CustomerID, booking.Customer.FirstName, booking.Customer.LastName);
                    count++;
                }
            }

            // Create a new array with the correct size and copy the data
            var result = new (int, string, string)[count];
            Array.Copy(flightBookings, result, count);

            return result;
        }


        public bool DeleteCustomer(int customerID)
        {
            Customer customerToDelete = FindCustomerByID(customerID);

            if (customerToDelete != null)
            {
                if (!CheckIfCustomerHasBookings(customerToDelete))
                {
                    for (int i = 0; i < customers.Length; i++)
                    {
                        if (customers[i] == customerToDelete)
                        {
                            customers[i] = null; // Delete the customer by setting the array entry to null
                            UpdateCustomersInDataStorage(); // Update the Customers.txt file
                            return true;
                        }
                    }
                }
                else
                {
                    Console.WriteLine("Cannot delete this customer. Customer has bookings.");
                }
            }
            else
            {
                Console.WriteLine("Customer not found.");
            }

            return false;
        }

        // Booking operations
        public bool MakeBooking(int flightNumber, int customerID)
        {
            Flight flight = FindFlightByNumbers(flightNumber);
            Customer customer = FindCustomerByID(customerID);

            if (flight != null && customer != null && !flight.IsFull())
            {
                Console.WriteLine("Booking Made.");
                for (int i = 0; i < bookings.Length; i++)
                {
                    if (bookings[i] == null)
                    {
                        bookings[i] = new Booking(flight, customer); // BookingDate and BookingNumber will be set automatically
                        UpdateBookingsInDataStorage(); // Update the Bookings.txt file
                        UpdateFlightsInDataStorage();//update the flight passengercount
                        return true;
                    }
                }
            }
            else
            {
                Console.WriteLine("Booking failed. Please check flight availability and customer details.");
            }
            return false;
        }

        private bool CheckIfCustomerHasBookings(Customer customer)
        {
            foreach (var booking in bookings)
            {
                if (booking != null && booking.Customer.CustomerID == customer.CustomerID)
                {
                    return true;
                }
            }
            return false;
        }

        private bool CheckIfFlightHasCustomers(Flight flight)
        {
            foreach (var booking in bookings)
            {
                if (booking != null && booking.Flight.FlightNumber == flight.FlightNumber)
                {
                    return true;
                }
            }
            return false;
        }

        public Customer FindCustomerByID(int customerID)
        {
            Customer customer = null;
            foreach (var c in customers)
            {
                if (c != null && c.CustomerID == customerID)
                {
                    customer = c;
                    break;
                }
            }
            return customer;
        }

        public void ViewBookings()
        {
            foreach (var booking in bookings)
            {
                if (booking != null)
                {
                    Console.WriteLine($"Booking Date: {booking.BookingDate}, Booking Number: {booking.BookingNumber}, " +
                                      $"Customer: {booking.Customer.FirstName} {booking.Customer.LastName}, " +
                                      $"Flight Number: {booking.Flight.FlightNumber}");
                }
            }
        }

        // Helper methods to update data in the respective .txt files
        private void UpdateCustomersInDataStorage()
        {
            string[] customerData = new string[customers.Length];
            int count = 0;
            for (int i = 0; i < customers.Length; i++)
            {
                if (customers[i] != null)
                {
                    customerData[count] = $"{customers[i].FirstName}|{customers[i].LastName}|{customers[i].Phone}";
                    count++;
                }
            }
            dataStorage.WriteCustomers(customerData);
        }

        private void UpdateFlightsInDataStorage()
        {
            string[] flightData = new string[flights.Length];
            int count = 0;
            for (int i = 0; i < flights.Length; i++)
            {
                if (flights[i] != null)
                {
                    flightData[count] = $"{flights[i].FlightNumber}|{flights[i].Origin}|{flights[i].Destination}|{flights[i].MaxSeats}|{flights[i].CurrentPassengerCount}";
                    count++;
                }
            }
            dataStorage.WriteFlights(flightData);
        }

        private void UpdateBookingsInDataStorage()
        {
            string[] bookingData = new string[bookings.Length];
            int count = 0;
            for (int i = 0; i < bookings.Length; i++)
            {
                if (bookings[i] != null)
                {
                    bookingData[count] = $"{bookings[i].Flight.FlightNumber}|{bookings[i].Customer.CustomerID}";
                    count++;
                }
            }
            dataStorage.WriteBookings(bookingData);
        }

        // Load data from files during initialization
        private void LoadCustomersFromDataStorage()
        {
            string[] customerData = dataStorage.ReadCustomers();

            for (int i = 0; i < customers.Length && i < customerData.Length; i++)
            {
                string[] customerInfo = dataStorage.SplitData(customerData[i]);
                if (customerInfo.Length >= 3)
                {
                    customers[i] = new Customer(customerInfo[0], customerInfo[1], customerInfo[2]);
                }
            }
        }

        private void LoadFlightsFromDataStorage()
        {
            string[] flightData = dataStorage.ReadFlights();

            for (int i = 0; i < flights.Length && i < flightData.Length; i++)
            {
                string[] flightInfo = dataStorage.SplitData(flightData[i]);
                if (flightInfo.Length >= 5)
                {
                    int flightNumber = int.Parse(flightInfo[0]);
                    string origin = flightInfo[1];
                    string destination = flightInfo[2];
                    int maxSeats = int.Parse(flightInfo[3]);
                    int currentPassengerCount = int.Parse(flightInfo[4]);
                    flights[i] = new Flight(flightNumber, origin, destination, maxSeats)
                    {
                        CurrentPassengerCount = currentPassengerCount
                    };
                }
            }
        }

        private void LoadBookingsFromDataStorage()
        {
            string[] bookingData = dataStorage.ReadBookings();

            for (int i = 0; i < bookings.Length && i < bookingData.Length; i++)
            {
                string[] bookingInfo = dataStorage.SplitData(bookingData[i]);
                if (bookingInfo.Length >= 2)
                {
                    int flightNumber = int.Parse(bookingInfo[0]);
                    int customerID = int.Parse(bookingInfo[1]);

                    Flight flight = FindFlightByNumbers(flightNumber);
                    Customer customer = FindCustomerByID(customerID);

                    if (flight != null && customer != null)
                    {
                        bookings[i] = new Booking(flight, customer,performActions: false);
                    }
                }
            }
        }
    }
}
