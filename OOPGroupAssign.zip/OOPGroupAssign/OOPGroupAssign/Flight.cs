﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPGroupAssign
{
    internal class Flight
    {
        public int FlightNumber { get; set; }
        public string Origin { get; set; }
        public string Destination { get; set; }
        public int MaxSeats { get; set; }
        public int CurrentPassengerCount { get; set; }

        public Flight(int flightNumber, string origin, string destination, int maxSeats)
        {
            FlightNumber = flightNumber;
            Origin = origin;
            Destination = destination;
            MaxSeats = maxSeats;
            CurrentPassengerCount = 0; // Initially, no passengers are booked.
        }

        public bool IsFull()
        {
            return CurrentPassengerCount >= MaxSeats;
        }

        public void BookPassenger()
        {
            if (!IsFull())
            {
                CurrentPassengerCount++;
            }
            else
            {
                Console.WriteLine("Flight is already full. Cannot book more passengers.");
            }
        }
    }

}
